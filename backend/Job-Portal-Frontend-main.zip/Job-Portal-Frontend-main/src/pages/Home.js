import React from 'react';

function Home(){
    return(
        <h2 style={{textAlign:'center'}}>Welcome to Job Portal Application!!!</h2>
    )
}

export default Home;
